package info.androidhive.barcodereader;

import android.app.Application;

import java.util.Dictionary;

public class ProductData extends Application {
    private Dictionary barcodeData;

    public Dictionary getBarcodeData(){
        return barcodeData;
    }

    public void setBarcodeData(String someKey, String someValue){
        this.barcodeData.put(someKey,someValue);
    }
}
